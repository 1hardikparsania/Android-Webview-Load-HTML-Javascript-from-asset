package com.exampledemo.parsaniahardik.webviewhtmldemonuts;

import android.content.Context;
import android.content.res.AssetManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class JavaScriptActivity extends AppCompatActivity {

    private WebView webView;
    private EditText editText;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_script);

        webView = (WebView)findViewById(R.id.mybrowser);

        final MyJavaScriptInterface myJavaScriptInterface
                = new MyJavaScriptInterface(this);
        webView.addJavascriptInterface(myJavaScriptInterface, "AndroidFunction");

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadData(getHTMLData(), "text/html", "UTF-8");

        editText = (EditText)findViewById(R.id.msg);
        button = (Button)findViewById(R.id.sendmsg);
        button.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                String msgToSend = editText.getText().toString();
                webView.loadUrl("javascript:callFromActivity(\"" + msgToSend + "\")");

            }});

    }

    private String getHTMLData() {
        StringBuilder html = new StringBuilder();
        try {
            AssetManager assetManager = getAssets();

            InputStream input = assetManager.open("load_JS_Demonuts.html");
            BufferedReader br = new BufferedReader(new InputStreamReader(input));
            String line;
            while ((line = br.readLine()) != null) {
                html.append(line);
            }
            br.close();
        } catch (Exception e) {
            //Handle the exception here
        }

        return html.toString();
    }

    public class MyJavaScriptInterface {
        Context mContext;

        MyJavaScriptInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void showToast(String toast){
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public void openAndroidDialog(){
            AlertDialog.Builder myDialog
                    = new AlertDialog.Builder(JavaScriptActivity.this);
            myDialog.setTitle("Dialog of JS!");
            myDialog.setMessage("I am generated from Android Code but I am in Webview and html-JS file !!!");
            myDialog.setPositiveButton("Cool!", null);
            myDialog.show();
        }

    }
}

